#Methods to evaluate square of a number
def evaluatesquare(x)
  puts x*x
end
