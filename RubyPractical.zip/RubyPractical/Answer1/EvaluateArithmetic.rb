#Methods to evaluate +,-,*,/,%
def addition(x,y)
  puts x+y
end

def subtraction(x,y)
  puts x-y
end

def multiplication(x,y)
  puts x*y
end

def division(x,y)
  puts x/y
end

def reminder(x,y)
  puts x%y
end
